/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.*;

/**
 *
 * @author WarPc
 */
public class Consultas extends Conexion{
    PreparedStatement pst=null;
    ResultSet rs=null;
    
    public boolean autentificacion (String usuario, String contraseña) {
        try {
            String consulta="select * from usuarios where nombre=? and contraseña=?";
            pst=getConexion().prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, contraseña);
            rs=pst.executeQuery();
            
            // si existe un registro
            if (rs.absolute(1)) {
                return true;
            }
        } catch (Exception ex) {
            System.err.println("Error: "+ex);
        }finally{
            try {
                 if(getConexion()!=null){ getConexion().close();}
                 if (pst!=null) {pst.close();}
                 if (rs!=null) {rs.close();}
            } catch (Exception e) {
                 System.err.println("Error: "+e);
            }
           
        }
        return false;
    }
    
    public boolean registrar(String nombre, String contraseña, String email){
        try {
            String consulta="insert into usuarios (nombre, contraseña, email) values(?,?,?)";
            pst=getConexion().prepareStatement(consulta);
            pst.setString(1, nombre);
            pst.setString(2, contraseña);
            pst.setString(3, email);
            
            if(pst.executeUpdate()==1){
                
                return true;
            }
            
        } catch (Exception ex) {
            System.err.println("Error: "+ex);
        }finally{
            try {
                 if(getConexion()!=null){ getConexion().close();}
                 if (pst!=null) {pst.close();}
            } catch (Exception e) {
                 System.err.println("Error: "+e);
            }
        }
        return false;
    }
    
    public static void main(String[] args) {
        Consultas co=new Consultas();
        System.out.println(co.registrar("joshel", "1234","ojs@gmail.com"));
    }
}
