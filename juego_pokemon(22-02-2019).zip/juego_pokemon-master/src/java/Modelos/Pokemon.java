/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author WarPc
 */
public class Pokemon {
    public int id;
    public int pokedex;
    public String nombre;
    public int salud;
    public int ataque;
    public int defensa;
    public int ataque_especial;
    public int defensa_especial;
    public int velocidad;
    public int total;
    public String tipo_1;
    public String tipo_2;
    public String especie;
    public String apodo;
    public int nivel;
    public String imagen;
    public String estado;
    public String idpkmn;
}
