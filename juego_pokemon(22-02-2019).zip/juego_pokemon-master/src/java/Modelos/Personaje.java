/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

public class Personaje {
    public int id;
    public String nombre;
    public int nivel;
    public int usuario;
    public String genero;
    public String raza;
    public String equipo;
    public String color_ojos;
    public String color_pelo;
    public String medalla_1;
    public String medalla_2;
    public String medalla_3;
    public int pokemonedas;
    public int experiencia;
    
}
