
  document.getElementById("imgpkch").addEventListener('click',function(){
    document.getElementById("imgpkch").style.border="1";
});


