/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelos;

/**
 *
 * @author Hospital
 */
public class Pokedex {
    public String ataque_1;
    public String ataque_2;
    public String ataque_3;
    public String ataque_4;
    
    
}
